# Final Year Project Template
##### GMIT Software Development

To use this, you should install [TeX Live](https://www.tug.org/texlive/), [TeXstudio](http://www.texstudio.org/) and [Pygments](http://pygments.org/download/) (which requires Python).

You'll also need to run ```pdflatex``` with the ```--shell-escape``` option.
See [this Stack Exchange post](http://tex.stackexchange.com/questions/99475/how-to-invoke-latex-with-the-shell-escape-flag-in-texmakerx) for details.